---
name: brutal-nouveau-react-native
description: Usa esta skill al escribir componentes React Native (apps para iOS y Android) dentro del sistema de diseño Brutal Nouveau. Traduce las decisiones de brutal-nouveau-core a código real de RN, documentando los límites reales de la plataforma frente a CSS. Consulta primero brutal-nouveau-core para saber qué técnica corresponde a cada caso; esta skill solo resuelve el código nativo.
---

# Brutal Nouveau — Implementación React Native

Traduce a React Native las decisiones de `brutal-nouveau-core`. No redefine qué técnica usar — consulta el core para eso.

**React Native no tiene motor CSS.** No existen `clip-path`, `mask-image`, ni `filter: drop-shadow()`. Copiar la sintaxis de `brutal-nouveau-web` aquí no va a funcionar — cada técnica necesita su propia solución nativa, en las referencias de abajo.

## Dependencias

```bash
npm install react-native-svg
npm install @react-native-masked-view/masked-view
```

## Técnicas — carga la referencia solo si la vas a usar

- Tile, avatar o ícono-only button (~1:1) → `references/squircle-rn.md`
- Sombra dura offset (en squircle o en card asimétrica) → `references/shadows-rn.md`
- Cards, modales, alertas, o el panel de acento único → `references/asymmetric-and-torn-rn.md`
- Cualquier botón rectangular → `references/buttons-rn.md`

## Tipografía

```jsx
// Título
fontFamily: Platform.select({ ios: 'Georgia', android: 'serif' }),
// Cuerpo
fontFamily: Platform.select({ ios: 'Avenir Next', android: 'sans-serif' }),
```

Si se necesita la ruta webfont (`Playfair Display` / `Poppins`), hay que empaquetar los `.ttf` con `expo-font` o vincularlos nativamente — no se cargan por URL como en web.

## Gotchas

- **RN no soporta radio elíptico por eje.** Es la causa más común de que un agente pierda tiempo intentando portar literalmente el CSS de `brutal-nouveau-web` — ese shorthand simplemente no existe aquí. Ver `references/buttons-rn.md` para la alternativa real.
- **`elevation` en Android siempre difumina.** No hay forma de pedirle a Android una sombra plana sin blur usando la API nativa de sombra — se necesita el `View` extra offset descrito en `references/shadows-rn.md`.
- **`box-shadow`/`shadowOffset` no siguen un `MaskedView`.** Ambos dibujan sobre la caja rectangular original del elemento, ignorando el recorte — la sombra de un squircle se resuelve con un `Svg` duplicado, nunca con las props de sombra nativas.
- **`MaskedView` es costoso en listas largas.** No lo apliques por fila en un `FlatList`/`FlashList` de cientos de ítems — usa esquinas asimétricas nativas ahí en su lugar.

## Antes de entregar

No existe todavía un validador automático para RN (a diferencia de `brutal-nouveau-web`, que sí trae `scripts/validate.py`) porque validar JSX/estilos de RN de forma confiable por texto plano da muchos falsos positivos. Revisa a mano contra esta lista:

1. ¿Ningún squircle usa `border`/sombra nativa directa — todos usan `Svg` duplicado para la sombra?
2. ¿Ningún botón usa `MaskedView` — todos usan radios por esquina calculados o `Svg` de fondo?
3. ¿En Android, las cards con sombra dura tienen el `View` extra offset detrás?
4. ¿Las listas largas evitan `MaskedView` por fila?
5. ¿Cada card de un mismo grid/lista tiene un patrón de esquina distinto a sus vecinas?
