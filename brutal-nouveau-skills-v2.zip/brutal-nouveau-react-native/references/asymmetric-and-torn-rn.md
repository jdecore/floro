# Esquinas asimétricas en React Native

RN sí soporta radio por esquina de forma nativa, sin SVG ni máscara:

```jsx
const cardStyle = {
  borderTopLeftRadius: 30,
  borderTopRightRadius: 8,
  borderBottomRightRadius: 30,
  borderBottomLeftRadius: 8,
  borderWidth: 3,
  borderColor: stroke,
};
```

Para la sombra dura, ver `references/shadows-rn.md`. Para bottom sheets: solo esquinas superiores, inferiores en `0`. Cada card de un mismo grid/lista debe usar un patrón distinto al de sus vecinas.

# Torn edge en React Native

No hay `clip-path`. Se dibuja el panel completo como un `Svg`/`Path` con el borde superior irregular, y el contenido va superpuesto encima con `position: absolute`:

```jsx
<View>
  <Svg width="100%" height={panelHeight} viewBox="0 0 500 300" preserveAspectRatio="none">
    <Path
      d="M0,10 L25,2 L50,8 ... L500,10 L500,300 L0,300 Z"
      fill={panelColor}
    />
  </Svg>
  <View style={{ position: 'absolute', top: 20, padding: 24 }}>{content}</View>
</View>
```

Máximo un panel de este tipo por pantalla.
