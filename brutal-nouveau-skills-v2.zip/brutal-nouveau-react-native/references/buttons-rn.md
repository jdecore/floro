# Botones en React Native

**Límite real: RN no tiene el shorthand `border-radius: x% / y%` de CSS.** Solo acepta un radio por esquina (mismo en x e y) — no hay forma nativa de un radio distinto en horizontal y vertical dentro de la misma esquina.

La forma correcta de aproximar el mismo efecto: calcular el radio en píxeles a partir del tamaño real del botón, sesgado hacia el eje menor (normalmente la altura, porque un botón es ancho y bajo):

```jsx
function organicButtonRadius(width, height) {
  const base = height * 0.55;
  return {
    borderTopLeftRadius: base * 1.1,
    borderTopRightRadius: base * 0.75,
    borderBottomRightRadius: base * 1.0,
    borderBottomLeftRadius: base * 0.65,
  };
}
```

Si necesitas fidelidad visual exacta con la versión web (mismo blob, no una aproximación), dibuja el fondo del botón como `Svg`/`Path` igual que el torn edge, con `TouchableOpacity` envolviendo el `Svg` + texto superpuesto. Usa esto solo si la marca lo exige pixel-perfect — el cálculo por píxeles de arriba es suficiente en la mayoría de los casos y evita una dependencia de SVG en cada botón de la app.

Ícono-only: es cuadrado, usa `references/squircle-rn.md`, no esta técnica.
