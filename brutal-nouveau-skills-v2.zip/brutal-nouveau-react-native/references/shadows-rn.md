# Sombra dura offset en React Native

## En elementos con squircle (MaskedView)

Ni `elevation` (Android) ni `shadowOffset` (iOS) respetan el recorte de `MaskedView` de forma confiable. La solución que funciona en ambas plataformas: dibujar la sombra como un segundo `Svg`/`Path` idéntico, del color `stroke`, posicionado *detrás* con un offset fijo:

```jsx
<View>
  <Svg style={{ position: 'absolute', top: 6, left: 6 }} width={size} height={size} viewBox="0 0 100 100">
    <Path d="M 0 34 C 0 7, ... Z" fill={strokeColor} />
  </Svg>
  <SquircleTile size={size} color={panelColor}>{children}</SquircleTile>
</View>
```

## En elementos con esquinas asimétricas (sin máscara)

```jsx
// iOS
shadowColor: stroke,
shadowOffset: { width: 5, height: 5 },
shadowOpacity: 1,
shadowRadius: 0,

// Android — 'elevation' SIEMPRE agrega blur/difuminado, no existe un equivalente
// de sombra plana nativo. Si necesitas la sombra dura idéntica, dibuja un View
// extra del color stroke, del mismo tamaño, detrás y offset:
<View style={{ position: 'absolute', top: 5, left: 5, ...cardStyle, backgroundColor: stroke, zIndex: -1 }} />
<View style={cardStyle}>{content}</View>
```
