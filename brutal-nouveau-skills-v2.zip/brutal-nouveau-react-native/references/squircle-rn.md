# Squircle en React Native

No hay `mask-image` en RN. Se logra con `MaskedView` de `@react-native-masked-view/masked-view`, usando un `Svg`/`Path` de `react-native-svg` como máscara:

```jsx
import MaskedView from '@react-native-masked-view/masked-view';
import Svg, { Path } from 'react-native-svg';

function SquircleTile({ children, size, color }) {
  return (
    <MaskedView
      style={{ width: size, height: size }}
      maskElement={
        <Svg width={size} height={size} viewBox="0 0 100 100">
          <Path
            d="M 0 34 C 0 7, 7 0, 34 0 L 66 0 C 93 0, 100 7, 100 34 L 100 66 C 100 93, 93 100, 66 100 L 34 100 C 7 100, 0 93, 0 66 Z"
            fill="black"
          />
        </Svg>
      }
    >
      <View style={{ flex: 1, backgroundColor: color }}>{children}</View>
    </MaskedView>
  );
}
```

En listas largas (`FlatList`/`FlashList`), evita `MaskedView` por fila — es costoso en listas de cientos de ítems. Usa esquinas asimétricas nativas (sin máscara) para filas con card.
